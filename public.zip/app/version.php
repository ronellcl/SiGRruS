<?php
define('SIGRRUS_VERSION', '1.0.0');
